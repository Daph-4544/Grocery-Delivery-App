export const mango_1 = require("../assets/images/mango_1.jpeg");
export const mango_2 = require("../assets/images/mango_2.jpeg");
export const mango_3 = require("../assets/images/mango_3.jpeg");
export const mango_4 = require("../assets/images/mango_4.jpeg");
export const orange_1 = require("../assets/images/orange_1.jpeg");
export const orange_2 = require("../assets/images/orange_2.jpeg");
export const orange_3 = require("../assets/images/orange_3.jpeg");
export const orange_4 = require("../assets/images/orange_4.jpeg");
export const berry_1 = require("../assets/images/berry_1.jpeg");
export const berry_2 = require("../assets/images/berry_2.jpeg");
export const berry_3 = require("../assets/images/berry_3.jpeg");
export const berry_4 = require("../assets/images/berry_4.jpeg");
export const apple_1 = require("../assets/images/apple_1.jpeg");
export const apple_2 = require("../assets/images/apple_2.jpeg");
export const apple_3 = require("../assets/images/apple_3.jpeg");
export const apple_4 = require("../assets/images/apple_4.jpeg");
export const pineaple_1 = require("../assets/images/pineaple_1.jpeg");
export const pineaple_2 = require("../assets/images/pineaple_2.jpeg");
export const pineaple_3 = require("../assets/images/pineaple_3.jpeg");
export const pineaple_4 = require("../assets/images/pineaple_4.jpeg");

const Images = {
    mango_1,
    mango_2,
    mango_3,
    mango_4,
    orange_1,
    orange_2,
    orange_3,
    orange_4,
    berry_1,
    berry_2,
    berry_3,
    berry_4,
    apple_1,
    apple_2,
    apple_3,
    apple_4,
    pineaple_1,
    pineaple_2,
    pineaple_3,
    pineaple_4
}

export default Images;