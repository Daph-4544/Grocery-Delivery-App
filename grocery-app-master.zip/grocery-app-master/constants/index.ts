import { COLORS,SIZES, FONTS } from "./theme";
import dummyData from "./dummyData";

export {
    COLORS,
    SIZES,
    FONTS,
    dummyData,
}