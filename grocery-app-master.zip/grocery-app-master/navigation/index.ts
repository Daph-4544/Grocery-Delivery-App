import Tabs from "./Tabs";

export {
    Tabs
}