import Home from "./Home";
import ProductDetail from "./ProductDetail";

export {
    Home,
    ProductDetail
}